create function LoginExist(p_login varchar2) return boolean as
  v_login student.login%TYPE;
  begin
    select login into v_login from student where login=p_login;
    return TRUE;
  exception
    when others then
    return FALSE;
  end;
/

