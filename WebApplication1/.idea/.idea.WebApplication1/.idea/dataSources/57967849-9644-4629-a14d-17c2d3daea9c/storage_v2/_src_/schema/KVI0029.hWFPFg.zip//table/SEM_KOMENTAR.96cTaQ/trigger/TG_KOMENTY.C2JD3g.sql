create trigger TG_KOMENTY
    after insert
    on SEM_KOMENTAR
    for each row
declare
  v_ban int;
  v_obsah clob;
  begin
    select ban into v_ban from sem_uzivatel  where uzivatel_id = :NEW.uzivatel_uzivatel_id;
--     if (v_ban = 127) then
--       v_obsah:='<div class="highlight"> ' || :new.obsah || '</div>';
--       update sem_komentar set obsah=v_obsah where komentar_id= :NEW.komentar_id;                              
--     end if;
  end;
/

