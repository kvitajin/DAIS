create procedure PrintAllStations as
  v_stanice int;
  v_vystup clob;
  v_koncentrace float;
  v_koncentraceV varchar2(50);
begin
  for mesta in (select * from CITY) loop
    select count(*) into v_stanice from STATION where CITY_ID=mesta.CITY_ID;
    v_vystup:=v_vystup || '<' || mesta.CITY_NAME || '>' || '<' || mesta.ZIP || '>' || '<' || v_stanice || '>' || CHR(13) || CHR(10);
    for stanice in (select * from STATION where CITY_ID=mesta.CITY_ID) loop
--       v_koncentraceV:='14336,9426';
  select cast(max(CONCENTRATION) as varchar2(50))  into v_koncentraceV from MEASUREMENT where STATION_ID=stanice.STATION_ID order by CONCENTRATION;
--       select cast(CONCENTRATION as varchar2(50))  into v_koncentraceV from MEASUREMENT m1 where STATION_ID=stanice.STATION_ID and not exists(
--         select m1.CONCENTRATION from MEASUREMENT  m2 where STATION_ID=stanice.STATION_ID and m2.CONCENTRATION>m1.CONCENTRATION);
      v_koncentraceV:= nvl(v_koncentraceV, 'Data nejsou dostupna');
      v_vystup:=v_vystup || 'Nazev stanice: ' || stanice.STATION_NAME || CHR(13) || CHR(10);
      v_vystup:=v_vystup || 'Namerena maximalni koncentrace: ' || v_koncentraceV || CHR(13) || CHR(10);
    end loop;
  end loop;
  DBMS_OUTPUT.put_line(v_vystup);
end;
/

