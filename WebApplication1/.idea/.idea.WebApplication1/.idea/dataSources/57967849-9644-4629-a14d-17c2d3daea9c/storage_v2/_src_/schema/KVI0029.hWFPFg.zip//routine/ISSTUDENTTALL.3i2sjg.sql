create procedure IsStudentTall as
  cursor c_student is select * from student;
    v_s Student%ROWTYPE;
    v_avgTallness FLOAT;
  begin
    select avg(tallness) into v_avgTallness from student;

    open c_student;
    loop
      fetch c_student into v_s;
      exit when c_student%notfound;

      if (v_s.TALLNESS<v_avgTallness)then
        update STUDENT set istall=0 where login=v_s.LOGIN;
      else
        update STUDENT set istall =1 where LOGIN=v_s.LOGIN;
      end if ;
    end loop;
    close c_student;
  end;
/

