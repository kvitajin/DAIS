create trigger ROCNIK_INSERT
    before insert
    on ROCNIK
    for each row
begin
  select rocnik_seq.nextval into :new.idRocnik from dual;
end;
/

