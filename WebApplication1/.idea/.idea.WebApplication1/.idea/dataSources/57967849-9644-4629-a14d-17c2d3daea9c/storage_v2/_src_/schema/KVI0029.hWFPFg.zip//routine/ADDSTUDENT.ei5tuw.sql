create procedure  AddStudent(p_login VARCHAR2, p_fname varchar2, p_lname varchar2, p_tallness int)
as
begin
  insert into STUDENT (LOGIN, FNAME, LNAME, TALLNESS) values (p_login, p_fname, p_lname, p_tallness);
end;
/

