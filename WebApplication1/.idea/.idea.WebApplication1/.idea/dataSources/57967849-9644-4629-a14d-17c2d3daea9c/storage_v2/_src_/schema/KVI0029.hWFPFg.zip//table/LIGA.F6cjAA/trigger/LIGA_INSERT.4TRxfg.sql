create trigger LIGA_INSERT
    before insert
    on LIGA
    for each row
begin
  select liga_seq.nextval into :new.idLiga from dual;
end;
/

