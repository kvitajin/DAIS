create trigger TG_SLUSNE_KOMENTARE
    after insert
    on SEM_KOMENTAR
    for each row
declare 
    delkaKomentare int;
    velkaPismena int;
    pocetvykricniku int; 
    vysledek float;
  begin
    delkaKomentare:= length(:new.obsah);
    velkaPismena:=0;
    pocetvykricniku:=0;
    for i in 1..delkaKomentare loop 
      if substr(:NEW.obsah,i, 1) = '!' then 
        pocetvykricniku:=pocetvykricniku+1;
      end if;
      if substr(:NEW.obsah, i, 1) >='A' AND substr(:NEW.obsah, i, 1) <='Z' then 
        velkaPismena:=velkaPismena+1;
      end if;
    end loop;
    vysledek:=velkaPismena/delkaKomentare;
    if vysledek>0.05 or pocetvykricniku>7 then 
      update sem_uzivatel set ban=ban+1 where uzivatel_id= :new.uzivatel_uzivatel_id;
    end if;
    
  end;
/

