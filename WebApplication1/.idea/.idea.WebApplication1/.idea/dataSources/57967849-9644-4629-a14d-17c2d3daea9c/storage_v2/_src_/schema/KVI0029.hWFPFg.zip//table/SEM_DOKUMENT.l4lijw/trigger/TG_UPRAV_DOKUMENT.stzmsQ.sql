create trigger TG_UPRAV_DOKUMENT
    before update
    on SEM_DOKUMENT
    for each row
declare
  v_now date;
begin
  v_now:=CURRENT_DATE;
  insert into sem_zmena_dokument(zmena_dokument_id, obsah, datum, dokument_dokument_id) values (seq_zmena_dokument.nextval, :OLD.obsah, v_now, :NEW.dokument_id);
end;
/

