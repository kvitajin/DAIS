create procedure Registruj(p_datumNarozeni date, p_nick varchar2, p_heslo varchar2, p_hesloZnova varchar2, p_email varchar2, p_obecId int) as --
    v_hash varchar2(70);
    v_vek int;
    v_pocet_uzivatelu int;
begin
    --     DBMS_OUTPUT.put_line('vek:' || v_vek);

--     select trunc(months_between(sysdate, p_datumNarozeni)/12)year into v_vek
--     from (select to_date(p_datumNarozeni, 'DDMMYYYY')  from dual);
--     DBMS_OUTPUT.put_line('vek:' || v_vek);
    if p_heslo= p_hesloZnova then
        select count(*) into v_pocet_uzivatelu from SEM_UZIVATEL where EMAIL=p_email;
        if v_pocet_uzivatelu=0 then
            v_hash:=p_heslo || 'krutoprisna sul';
            insert into SEM_UZIVATEL(uzivatel_id, nick, heslo, email, datum_narozeni, ban, obec_obec_id)
            VALUES (SEQ_UZIVATEL.nextval, p_nick, v_hash, p_email, p_datumNarozeni, 1, p_obecId);
        end if;
    end if;
end;
/

