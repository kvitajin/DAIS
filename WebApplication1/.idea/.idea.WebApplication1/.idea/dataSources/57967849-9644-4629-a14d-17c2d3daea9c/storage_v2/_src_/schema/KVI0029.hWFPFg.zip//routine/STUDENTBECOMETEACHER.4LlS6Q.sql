create procedure StudentBecomeTeacher (p_login varchar2, p_department varchar2) as
    v_fname STUDENT.fname%TYPE;
    v_lname STUDENT.lname%TYPE;
    v_tallness int;
  begin
    select STUDENT.fname, STUDENT.lname, STUDENT.TALLNESS into v_fname , v_lname , v_tallness from STUDENT where LOGIN=p_login;
    insert into Teacher(login, fname, lname, department) values (p_login, v_fname, v_lname, p_department);
    delete from STUDENT where LOGIN=p_login;
    commit;
  exception
    when others then
      DBMS_OUTPUT.put_line('error');
    rollback;
  end;
/

