create trigger AKTUALIZUJ
    after insert
    on MEASUREMENT
    for each row
begin
    update STATION set STATION.station_measurements=STATION.station_measurements+1 where STATION_ID=:new.STATION_ID;
  exception
    when others then
    DBMS_OUTPUT.put_line( 'o kurwa');
  end;
/

