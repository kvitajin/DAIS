create procedure p_AddSource(p_source_name varchar2, p_source_type varchar2, p_longtitude float, p_latitude float, p_city_name varchar2) as
  v_city_id int;
  v_cnt int;
  v_source_id int;
begin
  select count(*) into v_cnt from CITY where CITY_NAME=p_city_name;
  if v_cnt >0 then
      select CITY_ID into v_city_id from CITY where CITY_NAME=p_city_name;
  else
    select max(CITY_ID)+1 into v_city_id from CITY;
    insert into CITY (city_id, city_name, zip) values (v_city_id, p_city_name, '00000');
  end if;

  select max(SOURCE_ID)+1 into v_source_id from SOURCE;

  insert into SOURCE(source_id, source_name, source_type, longitude, latitude, city_id) values (v_source_id, p_source_name, p_source_type, p_longtitude, p_latitude, v_city_id);
end;
/

