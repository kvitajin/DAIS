create trigger KONTROLAKAPACITY
    before insert
    on STUDENTKURZ
    for each row
declare
    v_capacity int;
    v_count int;
    v_exception exception;
  begin
    select KAPACITA into v_capacity from KURZ where KOD=:new.kod;
    select count(*) into v_count from StudentKurz where kod =:new.kod;
  if v_count>=v_capacity then
    DBMS_OUTPUT.put_line('prekrocena kapacita');
    raise v_exception;
  end if;
end;
/

